//#include <SFML/Graphics.hpp>
//#include <queue>
//#include <iostream>
//using namespace std;
//
//sf::RenderWindow window(sf::VideoMode(1070, 920), "SFML works!");
//
//struct node
//{
//	string data;
//	node* left, * right, * parent;
//	sf::CircleShape nodeShape;
//	sf::RectangleShape Lline;
//	sf::RectangleShape Rline;
//	sf::Text tex;
//}
//*root;
//class BST
//{
//public:
//	BST();
//	void insert(string, node*, int, int, int, int);
//	void Display(node*);
//	bool isEmpty();
//	void Deletion(int);
//	node* SearchNode(int, node*);
//};
//bool BST::isEmpty()
//{
//	if (!root)
//		return true;
//	return false;
//}
//BST::BST()
//{
//	root = NULL;
//}
//void BST::insert(string data, node* p = root, int x = 250, int y = 50, int a = 260, int b = 85)
//{
//	node* ptr = new node;
//	ptr->nodeShape.setRadius(20);
//	ptr->nodeShape.setFillColor(sf::Color::Blue);
//	ptr->left = ptr->right = ptr->parent = NULL;
//	ptr->data = data;
//	ptr->nodeShape.setPosition(sf::Vector2f(x, y));
//
//
//	sf::Font font;
//	if (!font.loadFromFile("times.ttf"))
//	{
//		cout << "Failed to Load File";
//	}
//	sf::Text tex;
//	ptr->tex.setFont(font);
//	ptr->tex.setString(data);
//	ptr->tex.setCharacterSize(30);
//	ptr->tex.setPosition(x, y);
//
//
//
//	if (!root)
//	{
//		root = ptr;
//		return;
//	}
//	if (data >= p->data)
//	{
//		if (p->right)
//			insert(data, p->right, x + 50, y + 50, a + 50, b + 50);
//		else
//		{
//			p->right = ptr;
//			ptr->parent = p;
//			ptr->nodeShape.setPosition(sf::Vector2f((x + 50), (y + 50)));
//
//			ptr->tex.setFont(font);
//			ptr->tex.setString(data);
//			ptr->tex.setCharacterSize(30);
//			ptr->tex.setPosition(x + 50, y + 50);
//
//			ptr->parent->Rline.setSize(sf::Vector2f(50, 5));
//			ptr->parent->Rline.setFillColor(sf::Color::Cyan);
//			ptr->parent->Rline.setRotation(230);
//			ptr->parent->Rline.setPosition(sf::Vector2f(a + 50, b + 40));
//		}
//	}
//	else if (data < p->data)
//	{
//		if (p->left)
//			insert(data, p->left, x - 50, y + 50, a - 50, b + 50);
//		else
//		{
//			p->left = ptr;
//			ptr->parent = p;
//			ptr->nodeShape.setPosition(sf::Vector2f((x - 50), (y + 50)));
//
//			ptr->tex.setFont(font);
//			ptr->tex.setString(data);
//			ptr->tex.setCharacterSize(30);
//			ptr->tex.setPosition(x - 50, y + 50);
//
//			ptr->parent->Lline.setSize(sf::Vector2f(50, 5));
//			ptr->parent->Lline.setFillColor(sf::Color::Cyan);
//			ptr->parent->Lline.setRotation(130);
//			ptr->parent->Lline.setPosition(sf::Vector2f(a, b));
//		}
//	}
//}
//void BST::Display(node* p = root)
//{
//	if (!root)
//	{
//		cout << "Nothing to Display";
//		return;
//	}
//	queue<node*> obj;
//	obj.push(p);
//
//	sf::Font font;
//	if (!font.loadFromFile("times.ttf"))
//	{
//		cout << "Failed to Load File";
//	}
//	sf::Text tex;
//
//	while (!obj.empty())
//	{
//		node* temp = obj.front();
//
//		temp->tex.setFont(font);
//		window.draw(temp->nodeShape);
//		window.draw(temp->tex);
//
//		if (temp->left)
//		{
//			window.draw(temp->Lline);
//		}
//		if (temp->right)
//		{
//			window.draw(temp->Rline);
//		}
//		obj.pop();
//		if (temp->left)
//			obj.push(temp->left);
//		if (temp->right)
//			obj.push(temp->right);
//	}
//	window.display();
//}
//
//int main()
//{
//	string data;
//	BST obj;
//	while (window.isOpen())
//	{
//		cout << "Enter Number to Insert: ";
//		cin >> data;
//		obj.insert(data);
//		sf::Event event;
//		obj.Display();
//		while (window.pollEvent(event))
//		{
//			if (event.type == sf::Event::Closed)
//				window.close();
//		}
//
//		window.clear();
//	}
//
//	return 0;
//}