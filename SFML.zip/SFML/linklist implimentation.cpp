//#include <SFML/Graphics.hpp>
//#include<iostream>
//#include<string>
//using namespace std;
//void drawnodes(double x, double y, sf::RenderWindow& newwindow);
//int counter = 0;
//
//
//
//
//
//class linklist
//{
//
//	struct node
//	{
//		string data;
//		node* next;
//		sf::RectangleShape node;//(sf::Vector2f(50, 50));
//		sf::Text tex;
//		sf::RectangleShape line;//(sf::Vector2f(100, 1));// f represents the floating pouint
//
//	};
//	struct node* start;
//	struct node* end;
//
//
//
//public:
//	linklist()
//	{
//		start = NULL;
//		end = NULL;
//
//	}
//
//	node* creation(string data)
//	{
//		node* newnode = new node;
//		newnode->data = data;
//		newnode->next = NULL;
//		return newnode;
//
//	}
//
//	void insertion(string  data)
//	{
//		cout << "enter the data: ";
//		cin >> data;
//		node* newnode = creation(data);
//		if (start == NULL)
//		{
//			start = newnode;
//			end = start;
//		}
//
//		else
//		{
//			end->next = newnode;
//			end = newnode;
//		}
//	}
//
//
//
//	string display()
//	{
//		node* temp = start;
//		while (temp != NULL)
//		{
//			
//			cout<<temp->data;
//			return temp->data;
//			cout << endl;
//			temp = temp->next;
//			
//		}
//	}
//
//	void insertion_begining(string data)
//	{
//		cout << "enter the data: ";
//		cin >> data;
//		node* newnode = new node;
//		if (start == NULL)
//		{
//			start = newnode;
//			end = start;
//		}
//		else
//		{
//			newnode->data = data;
//			newnode->next = start;
//			start = newnode;
//		}
//
//
//	}
//
//	void insertion_end(string data)
//	{
//		cout << "enter the data: ";
//		cin >> data;
//		node* newnode = new node;
//		newnode->data = data;
//		newnode->next = NULL;
//		if (start == NULL)
//		{
//			start = newnode;
//
//		}
//		else
//		{
//			node* temp = start;
//			while (temp->next != NULL)
//			{
//				temp = temp->next;
//			}
//			temp->next = newnode;
//		}
//
//	}
//
//	void deletenode(string data) 
//	{
//				node* temp;
//				node* temp1;// previous node
//				if (start == NULL) {
//					cout << "List is Empty";
//				}
//				else {
//					if (start->data == data) {
//						temp = start;
//						temp1 = start->next;
//						delete temp;
//						temp = NULL;
//						start = temp1;
//					}
//					else {
//						temp = start;
//						while (temp->next != NULL) {
//							if (temp->next->data == data) {
//								temp1 = temp->next;
//								temp->next = temp->next->next;
//								delete temp1;
//								temp1 = NULL;
//		
//								break;
//							}
//							temp = temp->next;
//						}
//		
//					}
//		
//				}
//			}
//
//		void drawnodes(string data, double x, double y, sf::RenderWindow & newwindow)
//		{
//			/*int x = 50;
//			int y = 40;*/
//			/////////////loop///////////
//
//			sf::RectangleShape node(sf::Vector2f(50, 50));
//			node.setFillColor(sf::Color::Red);
//			node.setOutlineThickness(3.5);
//			node.setOutlineColor(sf::Color::White);
//			node.setPosition(sf::Vector2f(x, y));
//			sf::Font font;
//			if (!font.loadFromFile("times.ttf"))
//			{
//				cout << "failed loading file";
//			}
//			sf::Text tex;
//			tex.setFont(font);
//			string result = display();
//			tex.setString(result);
//			tex.setCharacterSize(25);
//			tex.setPosition(x, y);
//			sf::RectangleShape line(sf::Vector2f(100, 1));// f represents the floating pouint
//			line.setPosition(60, 60);
//			///to rotate the line//
//			line.rotate(360);
//
//
//			x = x + 50;// for the linear position
//			newwindow.draw(line);
//			newwindow.draw(node);
//			newwindow.draw(tex);
//
//		}
//
//
//
//
//	
//
//
//
//};
//int main()
//{
//
//	linklist obj1;
//	string data ;
//	int size = 0;
//	int options = 0;
//	cout << " press 1 for the insertion of the linklist: ";
//	cout << endl;
//
//	cout << " press 2 for the insertion of the linklist in the beginning: ";
//	cout << endl;
//
//	cout << " press 3 for the insertion of the linklist in the last: ";
//	cout << endl;
//	 
//
//	cout << " press 4 for the deletion of the node in the  linklist ";
//	cout << endl;
//
//	cout << "press -1 for quit the program ";
//	cout << endl;
//
//	cout << "enter your desired option: ";
//	cin >> options;
//	do
//	{
//		switch (options)
//		{
//			case 1:
//			{
//			cout << "enter the size of insertions: ";
//			cin >> size;
//			for (int i = 0; i < size; i++)
//			{
//				obj1.insertion(data);
//			}
//			//obj1.display();
//			break;
//
//				}
//			case 2:
//			{
//			cout << "enter the data in the begining: ";
//			cout << endl;
//			cout << "enter the size of insertions: ";
//			cin >> size;
//			for (int i = 0; i < size; i++)
//			{
//
//				obj1.insertion_begining(data);
//
//			}
//		//	obj1.display();
//			break;
//
//			}
//
//			case 3:
//			{
//			cout << "enter the data in the last: ";
//			cout << endl;
//			cout << "enter the size of insertions: ";
//			cin >> size;
//			for (int i = 0; i < size; i++)
//			{
//
//			//	obj1.insertion_end(data);
//
//			}
//			//obj1.display();
//			break;
//			}
//
//			case 4:
//			{
//
//			cout << "delete the element from the beginning: ";
//			cout << endl;
//			//obj1.deletenode(data);
//
//			}
//
//
//			default:
//			{
//			cout << "enter the correct data ";
//			}
//		}
//	} 
//		
//	while (options == -1);
//
//	
//	
//
//
//	sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!");
//	while (window.isOpen())
//	{
//		sf::Event event;
//		while (window.pollEvent(event))
//		{
//			if (event.type == sf::Event::Closed)
//				window.close();
//		}
//
//
//		window.clear();
//		for (int i = 0; i < size; i++)
//		{
//			obj1.drawnodes(data, 50, 40, window);
//		}
//		
//			//obj1.drawnodes(data,50, 40, window);
//		
//	
//		window.display();
//
//
//
//	}
//
//
//
//	system("pause");
//}
////void drawnodes(string data, double x, double y, sf::RenderWindow& newwindow)
////{
////	
////	sf::RectangleShape node(sf::Vector2f(50, 50));
////	node.setFillColor(sf::Color::Red);
////	node.setOutlineThickness(3.5);
////	node.setOutlineColor(sf::Color::White);
////	node.setPosition(sf::Vector2f(x, y));
////	sf::Font font;
////	if (!font.loadFromFile("times.ttf"))
////	{
////		cout << "failed loading file";
////	}
////	sf::Text tex;
////	tex.setFont(font);
////	string result=obj1.
////	tex.setString();
////	tex.setCharacterSize(25);
////	tex.setPosition(x, y);
////	sf::RectangleShape line(sf::Vector2f(100, 1));// f represents the floating pouint
////	line.setPosition(60, 60);
////	/////to rotate the line//
////	line.rotate(360);
////
////
////	//y = y + 50;
////	newwindow.draw(line);
////	newwindow.draw(node);
////	newwindow.draw(tex);
////	
////}