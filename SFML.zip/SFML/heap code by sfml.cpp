#include<SFML/Graphics.hpp>
#include <iostream>
#include <windows.h>
using namespace std;
using namespace sf;
#define max_length 8

//////////////////////////
 /////////////////


class Heap
{
    int* heap;
    int num;
    int RemovedKey;
public:

    Heap()
    {

        heap = new int[max_length];
        RemovedKey = num = 0;
    }
    int GetNum()
    {
        return this->num;
    }
    //return root element of min heap
    int GiveMini() {
        if (heap[0] != 0 && num > 0)
            return heap[0];

        return 0;
    }
    //extract root from min heap
    int ExtractMin(RenderWindow& window, Text tex, bool flag)
    {
        int data = heap[0]; RemovedKey = data;
        int n = num - 1; int count = n;
        Sleep(1000); DrawHeap(window, tex, flag, count, -1, -1, 0);
        swap(heap[0], heap[num - 1]);

        heap[num - 1] = 0;
        while (n >= 0)
        {
            if (heap[n] != 0)
                BalenceMiniHeap(n, window, tex, flag, count);
            n--;
        }
        num--;
        if (num >= 0)
        {
            return data;
        }
        else return 0;
    }
    //balancing min heap------heapify
    void BalenceMiniHeap(int a, RenderWindow& window, Text tex, bool flag, int count)
    {
        while (a != 0)
        {
            if (a > 0 && a < max_length)
            {
                if (heap[(a - 1) / 2] > heap[a])
                {
                    Sleep(1000); DrawHeap(window, tex, flag, count, (a - 1) / 2, a, -1); swap(heap[(a - 1) / 2], heap[a]); Sleep(1000); DrawHeap(window, tex, flag, count, a, (a - 1) / 2, -1);
                }
            }
            a--;
        }
    }
    //insert values in heap
    void Insertion(int d, RenderWindow& window, Text tex, bool flag)
    {
        if (num >= max_length) {
            cout << "HEAP IS FULL.....\n";
            return;
        }
        heap[num] = d;
        if (flag)
        {
            BalenceMiniHeap(num, window, tex, flag, num);
        }
        else
        {
            Balance_Max(d, window, tex, flag, num);
        }
        num++;

    }


    //display min heap
    void Print() {
        for (int i = 0; i < num; i++) {
            cout << heap[i] << "   ";
        }
        cout << endl;
    }

    //balancing max heap------heapify
    void Balance_Max(int a, RenderWindow& window, Text tex, bool flag, int count)
    {
        while (a != 0)
        {
            if (a > 0 && a < max_length)
            {
                if (heap[(a - 1) / 2] < heap[a])
                {
                    Sleep(1000); DrawHeap(window, tex, flag, count, (a - 1) / 2, a, -1);    swap(heap[(a - 1) / 2], heap[a]); Sleep(1000); DrawHeap(window, tex, flag, count, a, (a - 1) / 2, -1);
                }
            }
            a--;
        }

    }





    void DrawHeap(RenderWindow& window, Text tex, bool flag, int count, int cyan_index = -1, int yellow_index = -1, int red_index = -1)
    {
        window.clear(Color::White);
        if (flag == true)
        {
            tex.setString("\n\n\t\t:: Mini Heap :: "); window.draw(tex);
            tex.setString("\n\n\n\n\n\t\t\t\t  MIN HEAP Data : "); window.draw(tex);
            tex.setString(" \n \n\n\n\n\n\n\t\t\t\t Removed Data : "); window.draw(tex);

        }
        else if (flag == false)
        {
            tex.setString("\n\n\t\t:: Max Heap :: "); window.draw(tex);
            tex.setString("\n\n\n\n\n\t\t\t\t  Max HEAP Data : "); window.draw(tex);
            tex.setString(" \n \n\n\n\n\n\n\t\t\t\t Removed Data : "); window.draw(tex);
        }

        RectangleShape box(Vector2f(50, 25));
        float x = 278, y = 169; /// x+55
        for (int i = 0; i < 8; i++)
        {

            if (i == red_index) {
                box.setFillColor(Color::Red);  //// Removeing color 
            }
            else if (i == yellow_index)
            {
                box.setFillColor(Color::Yellow); //// 2nd color swap 
            }
            else if (i == cyan_index)
            {
                box.setFillColor(Color::Cyan); //// 1st color swap 
            }
            else
            {
                box.setFillColor(Color::White); //// normal
            }

            box.setOutlineThickness(4);
            box.setOutlineColor(Color::Black);
            box.setPosition(Vector2f(x, y));
            window.draw(box);
            x += 55;




        }

        x = 294; y = 168;
        string str;    int* arr = 0; arr = heap;
        for (int i = 0; i < count; i++)
        {
            str = to_string(arr[i]);  tex.setPosition(x, y);
            tex.setString(str); window.draw(tex);
            x += 55;
        }
        str = to_string(RemovedKey);
        tex.setPosition(294, 230); tex.setString(str); window.draw(tex);


        window.display();
    }

};


void MiniHeap(RenderWindow& window, Text tex)
{
    window.clear(Color::White);
    int n = 0;
    Heap h;
    tex.setString("\n\n\t\t:: Mini Heap :: "); window.draw(tex);

    int count = 0;

    tex.setString("\n\n\n\t\t --> Enter elements in Console Window <--"); window.draw(tex); window.display();
    cout << " \n\t\t Mini Heap Elements : " << endl;
    cout << "\n\t\t-1 will stop entery ||| Enter Element Upto 8 \n";
    for (int i = 0; i < max_length && n != -1; i++) {

        cout << "\n\t\t Enter element !=0 " << i << " : ";
        cin >> n;
        if (n == -1)
            break;
        h.Insertion(n, window, tex, true); count++; h.DrawHeap(window, tex, true, count, -1, -1, -1);
        system("cls");
    }

    cout << " \n\n\t\t  MIN HEAP DATA : ";
    h.Print();////


    char ch = '\0';
    while (ch != 'C') {

        window.clear(Color::White);
        system("cls");   if (count == 0) { break; }
        cout << "\n\n\t\t MIN HEAP Data : "; h.Print(); h.DrawHeap(window, tex, true, count, -1, -1, -1);
        tex.setString("\n\n\n\n\n\n\n\n\n\t  Cancelation                   ---> C "); window.draw(tex);
        cout << "\n\n\t  Cancelation                   ---> C ";
        tex.setString("\n\n\n\n\n\n\n\n\n\n\n\t  Remove Mini Key                ---> R"); window.draw(tex);
        cout << "\n\n\n\n\n\n\n\n\n\n\n\t  Remove Mini Key                ---> R ";
        cout << "\n\n\t Choice Here : ";
        cin >> ch;
        if (ch == 'R' || ch == 'r')
        {
            tex.setString("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t Removed Key : "); ////// Show Removed Key Here  window.draw(tex);
            cout << "\n\n\t\t Removed Key : " << h.ExtractMin(window, tex, true); count--; cout << endl; Sleep(1000); h.DrawHeap(window, tex, true, count, -1, -1, -1); system("pause");
        }

    }
    cout << endl << endl;
    system("pause");
}









void MAX_Heap(RenderWindow& window, Text tex)
{

    int n = 0;

    Heap h;
    window.clear(Color::White);

    tex.setString("\n\n\t\t:: Max Heap :: "); window.draw(tex);
    cout << "\n\n\t\t:: Max Heap :: " << endl;

    int count = 0;
    tex.setString("\n\n\n\t\t --> Enter elements in Console Window <--"); window.draw(tex); window.display();

    cout << "\n\t\t-1 will stop entery ||| Enter Element Upto 8 \n";
    for (int i = 0; i < max_length && n != -1; i++) {

        cout << "\n\t\t MAX HEAP DATA : ";
        h.Print();
        cout << "\n\t\t Enter element !=0 " << i << " : ";
        cin >> n;
        if (n == -1)
            break;
        h.Insertion(n, window, tex, false);   count++;   h.DrawHeap(window, tex, false, count, -1, -1, -1);
        system("cls");
    }
    char ch = '\0';
    while (ch != 'C') {
        window.clear(Color::White);
        system("cls");   if (count == 0) { break; }
        cout << "\n\n\t\t MAX HEAP Data : "; h.Print(); h.DrawHeap(window, tex, false, count, -1, -1, -1);
        cout << "\n\n\t  Cancelation                   ---> C ";
        tex.setString("\n\n\n\n\n\n\n\n\n\t  Cancelation                   ---> C "); window.draw(tex);

        cout << "\n\n\t  Remove Mini Key                ---> R ";

        cin >> ch;
        if (ch == 'R' || ch == 'r')
        {
            tex.setString("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t Removed Key : "); ////// Show Removed Key Here  window.draw(tex);
            cout << "\n\n\t\t Removed Key : " << h.ExtractMin(window, tex, false); count--; cout << endl; Sleep(1000); h.DrawHeap(window, tex, false, count, -1, -1, -1); system("pause");
        }

    }
    cout << endl << endl;
    system("pause");
}





/// <summary>
/// //////////
/// </summary>
/// <returns></returns>
int main()
{
    /// <summary>
    ///  Windows Settings 

    RenderWindow window(VideoMode(1440, 810), " --Heap Program-- ", Style::Resize);

    Font font;

    if (!font.loadFromFile("times.ttf"))//.ttf
    {

        cout << "\n\n\t Bismillah \n\n\t Font Not Loaded -> Error !!! " << endl; system("pause");

    }
    else {
        cout << " \n\t\t Sukar Allah !!!  Font Has Been Loaded , Ready to use !!! " << endl;
    }


    /// </summary>
    /// <returns></returns>





/// <summary>
///     Text Settings 

    Text tex;
    tex.setFont(font);
    tex.setCharacterSize(22);
    tex.setFillColor(Color::Black);
    /// </summary>
    /// <returns></returns>

    Event event;
    while (window.isOpen()) {
        while (window.pollEvent(event))
        {

            char ch = '\0';
            while (ch != 'e')
            {
                window.clear(Color::White);
                tex.setString("\n\n\t\t :: To Create :: ");    window.draw(tex);
                tex.setString("\n\n\n\n\t\t Mini Heap ---> [A] ");    window.draw(tex);
                tex.setString("\n\n\n\n\n\n\t\t Max Heap  ---> [B] ");    window.draw(tex);
                tex.setString("\n\n\n\n\n\n\n\n\t\t Exit      ---> [e] ");    window.draw(tex);
                tex.setString("\n\n\n\n\n\n\n\n\n\n\t\t Enter Choice on Console : ");    window.draw(tex);
                window.display();
                system("cls"); cout << "\n\t\t Make Input Here :: ";
                cin >> ch;
                if (ch == 'e')
                {

                    window.close();
                    return 0;
                }
                if (ch == 'A' || ch == 'a')
                {
                    system("cls");
                    MiniHeap(window, tex);
                }
                if (ch == 'B' || ch == 'b')
                {
                    system("cls");
                    MAX_Heap(window, tex);
                }


            }

            system("pause");
            /// </summary>
            /// <returns></returns>

            window.display();

        }
    }
}