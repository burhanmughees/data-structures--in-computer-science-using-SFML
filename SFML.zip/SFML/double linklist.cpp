//#include <SFML/Graphics.hpp>
//#include <iostream>
//#include<string>
//using namespace std;
//class list
//{
//	struct node 
//	{
//		string data;
//		node* next;
//		node* prev;
//		sf::RectangleShape node;//(sf::Vector2f(50, 50));
//		sf::Text tex;
//		sf::RectangleShape line;//(sf::Vector2f(100, 1));// f represents the floating pouint
//	};
//	node* head;
//	node* tail;
//public:
//	list() 
//	{
//		head = NULL;
//		tail = NULL;
//	}
//	void addNode(string data)
//	{
//		cout << "enter the data: ";
//		cin >> data;
//		node* newNode = new node;
//		newNode->data = data;
//		newNode->next = NULL;
//		if (head == NULL)
//		{
//			tail = newNode;
//			head = newNode;
//			newNode->prev = NULL;
//		}
//		else
//		{
//			tail->next = newNode;
//			newNode->prev = tail;
//			tail = newNode;
//		}
//	}
//
//
//
//	void conversionfunction(double x, double y, sf::RenderWindow& newwindow) //yahan parameter cheay x,y jo marzi dy dena
//	{
//		node* n = head;
//		string result;
//		//double x = 10; // yahan jo marzi x,y axis dy dena iska tumhain pta
//		//double y = 28;
//		while (n != NULL) //last taak print karway gi
//		{
//			result = display(n); // har node ka data return karway gi
//			cout << result << endl;
//			drawnodes(result, x, y, newwindow); //draw mai jakar print karwa day ga
//			x = x + 100;
//			n = n->next;
//		}
//	}
//
//	string display(node* p)
//	{
//		return p->data;
//	}
//
//
//
//
//
//	void addAnywhere(string data, string pos)
//	{
//		cout << "enter the data: ";
//		cin >> data;
//		node* temp = head;
//		bool check = false;
//		if (head == NULL) {
//			cout << " List is Empty ";
//		}
//		else {
//			while (temp != NULL)
//			{
//				if (temp->data == pos)
//				{
//					node* newNode = new node;
//					newNode->data = data;
//					if (temp->next == NULL)
//					{
//						newNode->next = NULL;
//						tail = newNode;
//						newNode->prev = temp;
//						temp->next = newNode;
//						check = true;
//						break;
//					}
//					newNode->next = temp->next;
//					temp->next = newNode;
//					newNode->prev = temp;
//					check = true;
//					break;
//				}
//				temp = temp->next;
//			}
//			if (!check) {
//				cout << "\nPosition is Not Found\n";
//			}
//		}
//	}
//
//
//
//
//
//	
//
//	void delNode(string pos)
//	{
//		cout << "enter the position: ";
//		cin >> pos;
//		node* temp = head;
//		bool check = false;
//		if (head == NULL) {
//			cout << "\nList is Empty\n";
//		}
//		else {
//			while (temp != NULL) {
//				if (temp->data == pos) {
//					if (temp->prev == NULL) {
//						node* temp1 = temp;
//						head = temp->next;
//						if (temp->next != NULL) {
//							temp->next->prev = NULL;
//						}
//						delete temp1;
//						check = true;
//						break;
//					}
//					if (temp->next == NULL) {
//						node* temp1 = temp;
//						tail = temp->prev;
//						temp->prev->next = NULL;
//						delete temp1;
//						check = true;
//						break;
//					}
//					temp->next->prev = temp->prev;
//					temp->prev->next = temp->next;
//					check = true;
//					break;
//				}
//				temp = temp->next;
//			}
//			if (!check) {
//				cout << "\nPosition is Not Found\n";
//			}
//		}
//	}
//
//	void display() {
//		node* temp = head;
//		if (head == NULL) {
//			cout << "\nList is Empty\n";
//		}
//		else {
//			while (temp != NULL) {
//				cout << temp->data << " ";
//				temp = temp->next;
//			}
//		}
//	}
//
//
//
//	
//
//
//
//
//	void drawnodes(string data, double x, double y, sf::RenderWindow& newwindow)
//			{
//				sf::RectangleShape node(sf::Vector2f(40, 40));
//				node.setFillColor(sf::Color::Red);
//				node.setOutlineThickness(3.5);
//				node.setOutlineColor(sf::Color::White);
//				node.setPosition(sf::Vector2f(x, y));
//				sf::Font font;
//				if (!font.loadFromFile("times.ttf"))
//				{
//					cout << "failed loading file";
//				}
//				sf::Text tex;
//				tex.setFont(font);
//				string result = data;
//				cout << "result= " << result << endl;
//				tex.setString(result);
//				tex.setCharacterSize(25);
//				tex.setPosition(x, y);
//				sf::RectangleShape line(sf::Vector2f(400, 1));
//				sf::RectangleShape line1(sf::Vector2f(400, 1));
//				line.setPosition(90, 90);
//				line1.setPosition(100, 100);
//				///to rotate the line//
//				line.rotate(360);
//				
//				x = x + 50;// for the linear position
//		
//				newwindow.draw(line);
//				newwindow.draw(line1);
//				newwindow.draw(node);
//				newwindow.draw(tex);
//		
//	}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//};
//
//int main()
//{
//
//	sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!");
//	
//	list obj1;
//	double x = 70;
//	double y = 80;
//	int opt = -1, size;
//	string pos, data;
//
//	while (!(opt == 0)) {
//		do
//		{
//				cout << "\nOption\n\n";
//				cout << "1:To Add node\n";
//				cout << "2:To Add node Anywhere\n";
//				cout << "3:To Delete node\n";
//				cout << "4:To Display List\n";
//				cout << "5:To Exit\n";
//				cout << "\nSelect Your Desired Option: ";
//				cin >> opt;
//				if (opt <= 0 || opt > 6)
//					{
//						cout << "\nError: Select Right Option\n";
//					}
//		} 
//		while (opt <= 0 || opt > 6);
//
//				switch (opt) 
//				{
//					case 1: 
//						{
//						while (window.isOpen())
//						{
//							sf::Event event;
//							while (window.pollEvent(event))
//							{
//								if (event.type == sf::Event::Closed)
//									window.close();
//							}
//
//
//							window.clear();
//							cout << "enter the size of insertions: ";
//							cin >> size;
//							for (int i = 0; i < size; i++)
//							{
//								obj1.addNode(data);
//							}
//							obj1.conversionfunction(x, y, window);
//							window.display();
//
//							break;
//
//						}
//
//							break;
//						}
//				
//					 
//
//						case 2: 
//							{
//								cout << "\nEnter position of Nodes in the string (1-so on): ";
//								cin >> pos;
//								while (window.isOpen())
//								{
//									sf::Event event;
//									while (window.pollEvent(event))
//									{
//										if (event.type == sf::Event::Closed)
//											window.close();
//									}
//
//
//									window.clear();
//									cout << "enter the size of insertions: ";
//									cin >> size;
//									for (int i = 0; i < size; i++)
//									{
//										obj1.addAnywhere(data,pos);
//									}
//									obj1.conversionfunction(x, y, window);
//									window.display();
//
//									break;
//
//								}
//
//								break;
//
//							}
//								  break;
//
//
//
//							case 3:
//								{
//									
//									while (window.isOpen())
//									{
//										sf::Event event;
//										while (window.pollEvent(event))
//										{
//											if (event.type == sf::Event::Closed)
//												window.close();
//										}
//
//
//										window.clear();
//										
//										
//											obj1.delNode(pos);
//										
//										obj1.conversionfunction(x, y, window);
//										window.display();
//
//										break;
//
//									}
//
//									break;
//								}
//
//
//							case 4:
//								{
//									cout << "\nDisplay List: \n";
//
//
//									while (window.isOpen())
//											{
//												sf::Event event;
//												while (window.pollEvent(event))
//												{
//															if (event.type == sf::Event::Closed)
//															window.close();
//												}
//
//
//												window.clear();
//
//												obj1.display();
//	
//
//
//
//												obj1.conversionfunction(x, y, window);
//												window.display();
//									}
//
//								}
//								  break;
//
//									case 5:
//									{
//										opt = 0;
//
//									}
//									break;
//				}
//	}
//
//
//
//
//
//
//
//
//
//
//
//
//	system("pause");
//	return 0;
//}
//
//
//
//
//
//
//
