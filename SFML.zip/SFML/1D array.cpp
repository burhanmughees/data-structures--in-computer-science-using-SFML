//#include <SFML/Graphics.hpp>
//#include<iostream>
//#include<string>
//using namespace std;
//void drawnodes(int* arr, int rows,  double x, double y, sf::RenderWindow& windowtopass);
//void insertion(int* arr, int rows,  double x, double y, sf::RenderWindow& windowtopass);
//void searching(int* arr, int rows, int key, double x, double y, sf::RenderWindow& windowtopass);
//
//
//
//int main()
//{
//	sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!");
//	int rows = 0;
//	int key = 0;
//
//	int columns = 0;
//	int*arr = NULL;
//	double x = 80;
//	double y = 70;
//	
//	int options = 0;
//	
//	for (;;)
//	{
//
//		cout << "press 1 to insert the data: ";
//		cout << endl;
//		cout << "press 2 to search the data: ";
//		cout << endl;
//		cout << "enter your desired option: ";
//		cin >> options;
//		switch (options)
//		{
//
//		case 1:
//		{
//			cout << "enter the size of rows: ";
//			cin >> rows;
//
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//						window.close();
//				}
//
//
//				window.clear();
//
//				insertion(arr, rows, x, y, window);
//				window.display();
//				
//				break;
//			}
//
//			break;
//		}
//
//		case 2:
//		{
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//						window.close();
//				}
//
//
//				window.clear();
//
//				searching(arr, rows, key, x, y, window);
//				window.display();
//				break;
//
//			}
//			break;
//		}
//
//		default:
//		{
//			cout << "enter the correct option. ";
//		}
//
//
//		}
//	}
//	
//	system("pause");
//}
//void drawnodes(int*arr, int rows,  double x, double y, sf::RenderWindow& windowtopass)
//{
//
//	sf::RectangleShape node(sf::Vector2f(30, 30));
//	node.setFillColor(sf::Color::Black);
//	node.setOutlineThickness(3.5);
//	node.setOutlineColor(sf::Color::White);
//	node.setPosition(sf::Vector2f(x, y));
//	sf::Font font;
//	if (!font.loadFromFile("times.ttf"))
//	{
//		cout << "failed loading file";
//	}
//	sf::Text tex;
//	tex.setFont(font);
//	int outputdata = arr[rows];
//	string result = to_string(outputdata);
//	tex.setString(result);
//	tex.setCharacterSize(25);
//	tex.setPosition(x, y);
//	//x = x + 50;
//	windowtopass.draw(node);
//	windowtopass.draw(tex);
//}
//void insertion(int*arr, int rows,  double x, double y, sf::RenderWindow& windowtopass)
//{
//
//	arr = new int [rows];
//	cout << "enter the data in the array: ";
//	cout << endl;
//	for (int i = 0; i < rows; i++)
//	{
//		cout << "enter the data at the " << i << "th index: ";
//		cin >> arr[i];
//
//	}
//	
//	for (int i = 0; i < rows; i++)
//	{
//		drawnodes(arr, i,  x, y, windowtopass);
//		x = x + 30;
//		
//		
//	}
//
//}
//void searching(int* arr, int rows,int key,double x,double y, sf::RenderWindow& windowtopass)
//{
//	cout << "Enter a number to serach in Array\n";
//	cin >> key;
//
//	
//	for (int i = 0; i < rows; i++) 
//	{
//		if (arr[i] == key)
//		{
//			cout << "element found at index " << i;
//			drawnodes(arr, i, x, y, windowtopass);
//			break;
//		}
//	}
//
//	if (key == rows) {
//		cout << "Element Not Present in Input Array\n";
//	}
//}
