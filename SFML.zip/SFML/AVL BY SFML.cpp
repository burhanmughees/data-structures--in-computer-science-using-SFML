//#include <SFML/Graphics.hpp>
//#include <queue>
//#include <iostream>
//using namespace std;
//
//sf::RenderWindow window(sf::VideoMode(1070, 920), "SFML works!");
//
//struct node
//{
//	string data;
//	node* left, * right, * parent;
//	int height;
//	sf::CircleShape nodeShape;
//	sf::RectangleShape Lline;
//	sf::RectangleShape Rline;
//	sf::Text tex;
//}
//*root;
//class AVL
//{
//public:
//	AVL();
//	void insert(string, node*, int, int, int, int);
//	void Display(node*);
//	bool isEmpty();
//	void Deletion(int);
//	node* SearchNode(int, node*);
//};
//bool AVL::isEmpty()
//{
//	if (!root)
//		return true;
//	return false;
//}
//AVL::AVL()
//{
//	root = NULL;
//}
//
//int Max(int a, int b)
//{
//	return((a > b) ? a : b);
//}
//
//int Height(node* ptr)
//{
//	if (ptr == NULL)
//		return 0;
//	else
//		return ptr->height;
//}
//
//node* rotateLeft(node* K1)
//{
//	node* K2;
//	K2 = K1->right;
//	K1->right = K2->left;
//	K2->left = K1;
//
//	K1->height = 1 + Max(Height(K1->left), Height(K1->right));
//	K2->height = 1 + Max(Height(K2->left), Height(K2->right));
//
//	return K2;
//}
//
//node* rotateRight(node* K1)
//{
//	node* K2;
//	K2 = K1->left;
//	K1->left = K2->right;
//	K2->right = K1;
//
//	K1->height = 1 + Max(Height(K1->left), Height(K1->right));
//	K2->height = 1 + Max(Height(K2->left), Height(K2->right));
//
//	return K2;
//}
//
//node* Balance(int key, node*& ptr)
//{
//	int balance = Height(ptr->left) - Height(ptr->right);
//
//	if (balance > 1)
//	{
//		if (Height(ptr->left) > Height(ptr->right))
//			return(rotateRight(ptr));
//		else
//		{
//			ptr->left = rotateLeft(ptr->left);
//			return(rotateRight(ptr));
//		}
//	}
//
//	if (balance < -1)
//	{
//		if (Height(ptr->right) > Height(ptr->left))
//			return(rotateLeft(ptr));
//		else
//		{
//			ptr->right = rotateRight(ptr->right);
//			return(rotateLeft(ptr));
//		}
//	}
//
//	return ptr;
//
//}
//
//
//void AVL::insert(string data, node* p = root, int x = 250, int y = 50, int a = 260, int b = 85)
//{
//	node* ptr = new node;
//	ptr->nodeShape.setRadius(20);
//	ptr->nodeShape.setFillColor(sf::Color::Blue);
//	ptr->left = ptr->right = ptr->parent = NULL;
//	ptr->data = data;
//	ptr->nodeShape.setPosition(sf::Vector2f(x, y));
//
//
//	sf::Font font;
//	if (!font.loadFromFile("times.ttf"))
//	{
//		cout << "Failed to Load File";
//	}
//	sf::Text tex;
//	ptr->tex.setFont(font);
//	ptr->tex.setString(data);
//	ptr->tex.setCharacterSize(30);
//	ptr->tex.setPosition(x, y);
//
//
//
//	if (!root)
//	{
//		root = ptr;
//		return;
//	}
//	if (data >= p->data)
//	{
//		if (p->right)
//			insert(data, p->right, x + 50, y + 50, a + 50, b + 50);
//		else
//		{
//			p->right = ptr;
//			ptr->parent = p;
//			ptr->nodeShape.setPosition(sf::Vector2f((x + 50), (y + 50)));
//
//			ptr->tex.setFont(font);
//			ptr->tex.setString(data);
//			ptr->tex.setCharacterSize(30);
//			ptr->tex.setPosition(x + 50, y + 50);
//
//			ptr->parent->Rline.setSize(sf::Vector2f(50, 5));
//			ptr->parent->Rline.setFillColor(sf::Color::Yellow);
//			ptr->parent->Rline.setRotation(230);
//			ptr->parent->Rline.setPosition(sf::Vector2f(a + 50, b + 40));
//		}
//	}
//	else if (data < p->data)
//	{
//		if (p->left)
//			insert(data, p->left, x - 50, y + 50, a - 50, b + 50);
//		else
//		{
//			p->left = ptr;
//			ptr->parent = p;
//			ptr->nodeShape.setPosition(sf::Vector2f((x - 50), (y + 50)));
//
//			ptr->tex.setFont(font);
//			ptr->tex.setString(data);
//			ptr->tex.setCharacterSize(30);
//			ptr->tex.setPosition(x - 50, y + 50);
//
//			ptr->parent->Lline.setSize(sf::Vector2f(50, 5));
//			ptr->parent->Lline.setFillColor(sf::Color::Yellow);
//			ptr->parent->Lline.setRotation(130);
//			ptr->parent->Lline.setPosition(sf::Vector2f(a, b));
//		}
//	}
//
//	ptr->height = 1 + Max(Height(ptr->left), Height(ptr->right));
//	(Balance(stoi(data), ptr)); //stoi changes string to int
//
//}
//void AVL::Display(node* p = root)
//{
//	if (!root)
//	{
//		cout << "Nothing to Display";
//		return;
//	}
//	queue<node*> obj;
//	obj.push(p);
//
//	sf::Font font;
//	if (!font.loadFromFile("times.ttf"))
//	{
//		cout << "Failed to Load File";
//	}
//	sf::Text tex;
//
//	while (!obj.empty())
//	{
//		node* temp = obj.front();
//
//		temp->tex.setFont(font);
//		window.draw(temp->nodeShape);
//		window.draw(temp->tex);
//
//		if (temp->left)
//		{
//			window.draw(temp->Lline);
//		}
//		if (temp->right)
//		{
//			window.draw(temp->Rline);
//		}
//		obj.pop();
//		if (temp->left)
//			obj.push(temp->left);
//		if (temp->right)
//			obj.push(temp->right);
//	}
//	window.display();
//}
//
//int main()
//{
//	string data;
//	AVL obj;
//	while (window.isOpen())
//	{
//		cout << "Enter Number to Insert: ";
//		cin >> data;
//		obj.insert(data);
//		sf::Event event;
//		obj.Display();
//		while (window.pollEvent(event))
//		{
//			if (event.type == sf::Event::Closed)
//				window.close();
//		}
//
//		window.clear();
//	}
//
//	return 0;
//}