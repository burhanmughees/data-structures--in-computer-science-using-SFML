//#include <SFML/Graphics.hpp>
//#include <iostream>
//#include<string>
//using namespace std;
//
//class Stack 
//{
//	struct Node 
//	{
//		string data;
//		Node* next;
//	};
//	Node* head;
//	Node* tail;
//	int top;
//public:
//	Stack()
//	{
//		top = -1;
//		head = NULL;
//		tail = NULL;
//	}
//	void push(string data) 
//	{
//		cout << "\nEnter Data to Push: ";
//		cin >> data;
//		if (isOverflow()) 
//		{
//			cout << "\nStack OverFLow\n";
//		}
//		else
//		{
//			++top;
//			Node* newNode = new Node;
//			newNode->data = data;
//			newNode->next = NULL;
//			if (head == NULL) 
//			{
//				head = newNode;
//				tail = newNode;
//			}
//			else
//			{
//				newNode->next = head;
//				head = newNode;
//			}
//		}
//	}
//	string pop(string data) 
//	{
//		cout << "\nData to Want to POP: ";
//		cin >> data;
//		if (isUnderflow()) {
//			cout << "\nStack id UnderFlow\n";
//		}
//		else {
//		string  data = head->data;
//			Node* temp = head;
//			head = head->next;
//			--top;
//			delete temp;
//			return data;
//		}
//	}
//
//	bool isUnderflow() {
//		if (top == -1) {
//			return true;
//		}
//		return false;
//	}
//	bool isOverflow() {
//		if (top == 10) {
//			return true;
//		}
//		return false;
//	}
//
//	
//	void display() {
//		Node* current = head;
//		if (isUnderflow()) {
//			cout << "\nStack is Empty\n";
//		}
//		else {
//			while (current != NULL) {
//				cout << current->data << endl;
//				current = current->next;
//			}
//		}
//	}
//
//
//	void conversionfunction(double x, double y, sf::RenderWindow& newwindow) //yahan parameter cheay x,y jo marzi dy dena
//	{
//		Node* n = head;
//		string result;
//		//double x = 10; 
//		//double y = 28;
//		while (n != NULL) //last taak print karway gi
//		{
//			result = display(n); // har Node ka data return karway gi
//			cout << result << endl;
//			drawnodes(result, x, y, newwindow); //draw mai jakar print karwa day ga
//			x = x + 40;
//			n = n->next;
//		}
//	}
//
//	string display(Node* p)
//	{
//		return p->data;
//	}
//
//
//
//		void drawnodes(string data, double x, double y, sf::RenderWindow& newwindow)
//			{
//				sf::RectangleShape Node(sf::Vector2f(40, 40));
//				Node.setFillColor(sf::Color::Red);
//				Node.setOutlineThickness(3.5);
//				Node.setOutlineColor(sf::Color::White);
//				Node.setPosition(sf::Vector2f(x, y));
//				sf::Font font;
//				if (!font.loadFromFile("times.ttf"))
//				{
//					cout << "failed loading file";
//				}
//				sf::Text tex;
//				tex.setFont(font);
//				string result = data;
//				cout << "result= " << result << endl;
//				tex.setString(result);
//				tex.setCharacterSize(25);
//				tex.setPosition(x, y);
//				sf::RectangleShape line(sf::Vector2f(400, 1));
//				//sf::RectangleShape line1(sf::Vector2f(100, 1));
//				//line.setPosition(, 60);
//				
//				///to rotate the line//
//				//line.rotate(360);
//				
//				//x = x + 30;// for the linear position
//		
//				//newwindow.draw(line);
//				newwindow.draw(Node);
//				newwindow.draw(tex);
//		
//	}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//};
//
//
//
//int main()
//{
//	
//	sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!");
//	Stack obj1;
//	int size = 0;
//	int opt = 0;
//	string data= " ";
//	double x = 80;
//	double y = 70;
//	while (opt != 6)
//	{
//		do
//		{
//			cout << "\nWhat Do You Want\n";
//			cout << "1: Push\n";
//			cout << "2: Pop\n";
//			cout << "3: Top Location\n";
//			cout << "3: Is UnderFlow\n";
//			cout << "4: Is OverFLow\n";
//			cout << "5: Display Stack\n";
//			cout << "6: Exit\n";
//			cout << "\nEnter Your Desired Choice: ";
//			cin >> opt;
//			if (opt <= 0 || opt > 6)
//			{
//				cout << "\nEnter Right Choice\n";
//			}
//		} 
//		while (opt <= 0 || opt > 7);
//		switch (opt)
//		{
//		case 1: 
//		{
//			cout << "ENTER THE DATA IN THE STACK.";
//			cout << endl;
//			
//						cout << endl;
//						while (window.isOpen())
//													{
//														sf::Event event;
//														while (window.pollEvent(event))
//														{
//															if (event.type == sf::Event::Closed)
//																window.close();
//														}
//							
//							
//														window.clear();
//														cout << "enter the size of insertions: ";
//														cin >> size;
//														for (int i = 0; i < size; i++)
//														{
//															obj1.push(data);
//														}
//														obj1.conversionfunction(x, y, window);
//														window.display();
//							
//														break;
//							
//													}
//							
//														break;
//			
//			
//		}
//		case 2: 
//		{
//			
//			cout << endl;
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//						window.close();
//				}
//
//
//				window.clear();
//			
//				
//					obj1.pop(data);
//				
//				obj1.conversionfunction(x, y, window);
//				window.display();
//
//				break;
//
//			}
//
//			break;
//		}
//		
//		case 3:
//		{
//			if (obj1.isUnderflow()) 
//			{
//				cout << "\nStack is Under Flow\n";
//			}
//			else
//			{
//				cout << "\nStack is not Under Flow\n";
//			}
//			break;
//		}
//		case 4:
//		{
//			if (obj1.isOverflow()) 
//			{
//				cout << "\nStack is Over Flow\n";
//			}
//			else 
//			{
//				cout << "\nStack is not Over Flow\n";
//			}
//			break;
//		}
//		case 5:
//		{
//			cout << "\nStack\n";
//			obj1.display();
//			break;
//		}
//		case 7:
//			break;
//		}
//
//
//
//	}
//
//
//
//
//
//
//
//	system("pause");
//	return 0;
//
//}
//
//
//	
