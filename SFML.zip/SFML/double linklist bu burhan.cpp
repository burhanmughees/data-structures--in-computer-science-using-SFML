//#include<iostream>
//#include<string>
//#include <SFML/Graphics.hpp>
//using namespace std;
//class dll
//{
//	struct node
//	{
//		string  data;
//		node* next;
//		node* previous;
//	};
//	node* start;
//	node* end;
//
//public:
//	dll()
//	{
//		start = NULL;
//		end = NULL;
//	}
//
//	node* creation(string  data)
//	{
//		node* newnode = new node;
//		newnode->data = data;
//		newnode->next = NULL;
//		newnode->previous = NULL;
//		return newnode;
//
//	}
//
//
//
//	void insertion(string data)
//	{
//		cout << "enter the data: ";
//		cin >> data;
//		if (start == NULL)
//		{
//			start = creation(data);
//			end = start;
//		}
//		else
//		{
//
//
//
//			end->next = creation(data);
//			end->next->previous = end;
//			end = end->next;
//
//
//
//
//
//		}
//
//	}
//
//	void delete_beginning()
//	{
//		node* deletenode = start;
//		start = deletenode->next;
//		start->previous = NULL;
//		free(deletenode);
//	}
//
//	void delete_end()
//	{
//		node* deletenode;
//		deletenode = end;
//		end->next = NULL;
//		end = end->previous;
//		free(deletenode);
//
//	}
//
//
//	void delete_anywhere(string pos)
//			{
//				cout << "enter the position: ";
//				cin >> pos;
//				node* temp = start;
//				bool check = false;
//				if (start == NULL) {
//					cout << "\nList is Empty\n";
//				}
//				else {
//					while (temp != NULL) {
//						if (temp->data == pos) {
//							if (temp->previous == NULL) {
//								node* temp1 = temp;
//								start = temp->next;
//								if (temp->next != NULL) {
//									temp->next->previous = NULL;
//								}
//								delete temp1;
//								check = true;
//								break;
//							}
//							if (temp->next == NULL) {
//								node* temp1 = temp;
//								end = temp->previous;
//								temp->previous->next = NULL;
//								delete temp1;
//								check = true;
//								break;
//							}
//							temp->next->previous = temp->previous;
//							temp->previous->next = temp->next;
//							check = true;
//							break;
//						}
//						temp = temp->next;
//					}
//					if (!check) {
//						cout << "\nPosition is Not Found\n";
//					}
//				}
//			}
//
//
//
//	void display1(string data)
//	{
//		node* newnode = start;
//		while (newnode->next != NULL)
//		{
//			cout << "the data you entered is: ";
//			cout << newnode->data;
//			newnode = newnode->next;
//		}
//	}
//
//
//	void conversionfunction(double x, double y, sf::RenderWindow& newwindow) //yahan parameter cheay x,y jo marzi dy dena
//	{
//		node* n = start;
//		string result;
//		//double x = 10; // yahan jo marzi x,y axis dy dena iska tumhain pta
//		//double y = 28;
//		while (n != NULL) //last taak print karway gi
//		{
//			result = display(n); // har Node ka data return karway gi
//			cout << result << endl;
//			drawnodes(result, x, y, newwindow); //draw mai jakar print karwa day ga
//			x = x + 100;
//			n = n->next;
//		}
//	}
//
//
//	string display(node* p)
//	{
//		return p->data;
//	}
//
//
//
//		void drawnodes(string data, double x, double y, sf::RenderWindow& newwindow)
//			{
//				sf::RectangleShape Node(sf::Vector2f(40, 40));
//				Node.setFillColor(sf::Color::Red);
//				Node.setOutlineThickness(3.5);
//				Node.setOutlineColor(sf::Color::White);
//				Node.setPosition(sf::Vector2f(x, y));
//				sf::Font font;
//				if (!font.loadFromFile("times.ttf"))
//				{
//					cout << "failed loading file";
//				}
//				sf::Text tex;
//				tex.setFont(font);
//				string result = data;
//				cout << "result= " << result << endl;
//				tex.setString(result);
//				tex.setCharacterSize(25);
//				tex.setPosition(x, y);
//				sf::RectangleShape line(sf::Vector2f(300, 1));
//				sf::RectangleShape line1(sf::Vector2f(100, 1));
//				line.setPosition(80, 80);
//				
//				///////to rotate the line//
//				line.rotate(360);
//				
//				y = y + 50;// for the linear position
//		
//				newwindow.draw(line);
//				newwindow.draw(Node);
//				newwindow.draw(tex);
//		
//	}
//
//};
//int main()
//{
//	sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!");
//	dll obj1;
//	string data = "";
//	int size = 0;
//	string position;
//	int options = 0;
//	double x = 80;
//	double y = 70;
//
//	for (;;)
//	{
//		cout << "press 1 to enter the data:";
//		cout << endl;
//		cout << "press 2 to delete from the beginning:";
//		cout << endl;
//		cout << "press 3 to delete from the end:";
//		cout << endl;
//
//		cout << "press 4 to delete any node:";
//		cout << endl;
//		cout << "enter your desired option: ";
//		cin >> options;
//
//		switch (options)
//		{
//		case 1:
//		{
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//					{
//						window.close();
//					}
//				}
//				window.clear();
//				cout << "enter the no of nodes you want to enter data: ";
//				cin >> size;
//				for (int i = 0; i < size; i++)
//				{
//					obj1.insertion(data);
//					cout << endl;
//				}
//				obj1.conversionfunction(x, y, window);
//				window.display();
//
//				break;
//
//
//			}
//			break;
//		}
//		case 2:
//		{
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//					{
//						window.close();
//					}
//				}
//				window.clear();
//
//
//				obj1.delete_beginning();
//				cout << endl;
//
//				obj1.conversionfunction(x, y, window);
//				window.display();
//
//				break;
//
//
//			}
//			break;
//		}
//
//
//
//		case 3:
//		{
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//					{
//						window.close();
//					}
//				}
//				window.clear();
//
//
//				obj1.delete_end();
//				cout << endl;
//
//				obj1.conversionfunction(x, y, window);
//				window.display();
//
//				break;
//
//
//			}
//			break;
//		}
//
//		case 4:
//		{
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//					{
//						window.close();
//					}
//				}
//				window.clear();
//
//
//				obj1.delete_anywhere(position);
//				cout << endl;
//
//				obj1.conversionfunction(x, y, window);
//				window.display();
//
//				break;
//
//
//			}
//			break;
//		}
//
//		default:
//		{
//			cout << "enter the correct option: ";
//		}
//
//		}
//	}
//	
//
//	
//
//
//
//	system("pause");
//}
