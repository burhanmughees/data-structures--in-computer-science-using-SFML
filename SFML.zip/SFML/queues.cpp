//#include <SFML/Graphics.hpp>
//#include <iostream>
//#include<string>
//using namespace std;
//
//class Queue {
//	struct Node 
//	{
//		string data;
//		Node* next;
//	};
//	Node* head;
//	Node* tail;
//	int front;
//	int rare;
//
//public:
//	Queue() {
//		front = -1;
//		rare = -1;
//		head = NULL;
//		tail = NULL;
//	}
//	void Enqueue(string data)
//	{
//		cout << "\nEnter Data to Enqueue: ";
//		cin >> data;
//		if (isOverflow()) {
//			cout << "\nQueue OverFLow\n";
//		}
//		else {
//			Node* ptr = new Node;
//			
//			        ptr->data = data;
//			
//			        if (head == nullptr)
//			
//			        {
//			
//			            head = ptr;
//			
//			            tail = ptr;
//			
//			            ptr->next = nullptr;
//			
//			        }
//			
//					else
//
//					{
//
//						tail->next = ptr;
//
//						ptr->next = nullptr;
//
//						tail = ptr;
//
//					}
//		}
//	}
//	
//
//	string deQueue()
//	{
//		if (front == rare) {
//			cout << "\nQueue id UnderFlow\n";
//		}
//		else {
//			if (head == NULL) {
//				return NULL;
//			}
//			else {
//				string data = head->data;
//				Node* temp = head;
//				head = head->next;
//				++rare;
//				delete temp;
//				return data;
//			}
//		}
//	}
//
//
//
//
//	bool isUnderflow() {
//		if (front == rare) {
//			return true;
//		}
//		return false;
//	}
//	bool isOverflow() {
//		if (front - rare == 3 || rare - front == 3) {
//			return true;
//		}
//		return false;
//	}
//	void display() {
//		Node* current = head;
//		if (isUnderflow()) {
//			cout << "\nQueue is Empty\n";
//		}
//		else {
//			while (current != NULL) {
//				cout << current->data << endl;
//				current = current->next;
//			}
//		}
//	}
//
//
//
//	void conversionfunction(double x, double y, sf::RenderWindow& newwindow) //yahan parameter cheay x,y jo marzi dy dena
//	{
//		Node* n = head;
//		string result;
//		//double x = 10; // yahan jo marzi x,y axis dy dena iska tumhain pta
//		//double y = 28;
//		while (n != NULL) //last taak print karway gi
//		{
//			result = display(n); // har Node ka data return karway gi
//			cout << result << endl;
//			drawnodes(result, x, y, newwindow); //draw mai jakar print karwa day ga
//			x = x + 100;
//			n = n->next;
//		}
//	}
//
//	string display(Node* p)
//	{
//		return p->data;
//	}
//
//
//
//		void drawnodes(string data, double x, double y, sf::RenderWindow& newwindow)
//			{
//				sf::RectangleShape Node(sf::Vector2f(40, 40));
//				Node.setFillColor(sf::Color::Red);
//				Node.setOutlineThickness(3.5);
//				Node.setOutlineColor(sf::Color::White);
//				Node.setPosition(sf::Vector2f(x, y));
//				sf::Font font;
//				if (!font.loadFromFile("times.ttf"))
//				{
//					cout << "failed loading file";
//				}
//				sf::Text tex;
//				tex.setFont(font);
//				string result = data;
//				cout << "result= " << result << endl;
//				tex.setString(result);
//				tex.setCharacterSize(25);
//				tex.setPosition(x, y);
//				sf::RectangleShape line(sf::Vector2f(300, 1));
//				//sf::RectangleShape line1(sf::Vector2f(100, 1));
//				line.setPosition(80, 80);
//				
//				///to rotate the line//
//				line.rotate(360);
//				
//				y = y + 50;// for the linear position
//		
//				newwindow.draw(line);
//				newwindow.draw(Node);
//				newwindow.draw(tex);
//		
//	}
//
//
//
//};
//
//
//
//int main()
//{
//	sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!");
//	Queue s;
//	int opt = 0;
//	int size = 0;
//	string data;
//	double y= 70;
//	double x = 80;
//	while (opt != 6) {
//		do {
//			cout << "\nWhat Do You Want\n";
//			cout << "1: Enqueue\n";
//			cout << "2: DeQoueue\n";
//			cout << "3: Is UnderFlow\n";
//			cout << "4: Is OverFLow\n";
//			cout << "5: Display Queue\n";
//			cout << "6: Exit\n";
//			cout << "\nEnter Your Choice: ";
//			cin >> opt;
//			if (opt <= 0 || opt > 6) {
//				cout << "\nEnter Right Choice\n";
//			}
//		} while (opt <= 0 || opt > 6);
//		switch (opt) {
//		case 1: {
//			
//
//
//
//			while (window.isOpen())
//																	{
//																		sf::Event event;
//																		while (window.pollEvent(event))
//																		{
//																			if (event.type == sf::Event::Closed)
//																				window.close();
//																		}
//											
//											
//																		window.clear();
//																		cout << "enter the size of insertions: ";
//																		cin >> size;
//																		for (int i = 0; i < size; i++)
//																		{
//																			s.Enqueue(data);
//																		}
//																		s.conversionfunction(x, y, window);
//																		window.display();
//											
//																		break;
//											
//																	}
//											
//																		break;
//							
//
//
//
//
//
//
//
//			
//			
//		}
//		case 2:
//		{
//
//			while (window.isOpen())
//			{
//				sf::Event event;
//				while (window.pollEvent(event))
//				{
//					if (event.type == sf::Event::Closed)
//						window.close();
//				}
//
//
//				window.clear();
//				
//				if (s.isUnderflow()) {
//					cout << "\nQueue  is Empty\n";
//				}
//				else {
//
//					cout << "\nData to Want to Dequeue: ";
//					cout << s.deQueue();
//				}
//
//
//				s.conversionfunction(x, y, window);
//				window.display();
//
//				break;
//
//			}
//
//			break;
//
//		
//		}
//		case 3:
//		{
//			if (s.isUnderflow()) {
//				cout << "\nQueue is Under Flow\n";
//			}
//			else {
//				cout << "\nQueue is not Under Flow\n";
//			}
//			break;
//		}
//		case 4:
//		{
//			if (s.isOverflow()) {
//				cout << "\nQueue is Over Flow\n";
//			}
//			else {
//				cout << "\nQueue is not Over Flow\n";
//			}
//			break;
//		}
//		case 5:
//		{
//			cout << "\nQueue\n";
//			s.display();
//			break;
//		}
//		case 6:
//			break;
//		}
//
//
//
//	}
//	system("pause");
//	return 0;
//
//}
//
//
//	
//
//
