//#include <SFML/Graphics.hpp>
//#include<iostream>
//#include<string>
//using namespace std;
//void drawnodes(int** arr, int rows, int columns, double x, double y, sf::RenderWindow& newwindow);
//void insertion(int** arr, int rows, int columns, double x, double y, sf::RenderWindow& newwindow);
//
//
//
//
//int main()
//{
//	sf::RenderWindow window(sf::VideoMode(1080, 720), "SFML works!");
//	int rows = 0;
//	int columns = 0;
//	int** arr = NULL;
//	double x = 80;
//	double y = 70;
//	cout << "enter the size of rows: ";
//	cin >> rows;
//	cout << "enter the size of columns: ";
//	cin >> columns;
//
//
//	
//
//	while (window.isOpen())
//	{
//		sf::Event event;
//		while (window.pollEvent(event))
//		{
//			if (event.type == sf::Event::Closed)
//				window.close();
//		}
//
//
//		window.clear();
//		
//		insertion(arr, rows, columns, x, y, window);
//		window.display();
//
//		
//	}
//	system("pause");
//}
//void drawnodes(int** arr, int rows, int columns, double x, double y, sf::RenderWindow& newwindow)
//{
//
//	sf::RectangleShape node(sf::Vector2f(30, 30));
//	node.setFillColor(sf::Color::Black);
//	node.setOutlineThickness(3.5);
//	node.setOutlineColor(sf::Color::White);
//	node.setPosition(sf::Vector2f(x, y));
//	sf::Font font;
//	if (!font.loadFromFile("times.ttf"))
//	{
//		cout << "failed loading file";
//	}
//	sf::Text tex;
//	tex.setFont(font);
//	int outputdata = arr[rows][columns];
//	string result = to_string(outputdata);
//	tex.setString(result);
//	tex.setCharacterSize(25);
//	tex.setPosition(x, y);
//	//x = x + 50;
//	newwindow.draw(node);
//	newwindow.draw(tex);
//}
//void insertion(int** arr, int rows, int columns, double x, double y, sf::RenderWindow& newwindow)
//{
//
//	arr = new int* [rows];
//	for (int i = 0; i < rows; i++)
//	{
//		arr[i] = new int[columns];
//
//	}
//	cout << "enter the data in the array: ";
//	for (int i = 0; i < rows; i++)
//	{
//		for (int j = 0; j < columns; j++)
//		{
//			cout << "enter the " << i << "th index and " << j << "th index: ";
//			cin >> arr[i][j];
//		}
//	}
//	for (int i = 0; i < rows; i++)
//	{
//		
//		for (int j = 0; j < columns; j++)
//		{
//			drawnodes(arr, i, j, x, y, newwindow);
//			x = x + 30;
//			
//		}
//		y = y +20  ;
//	}
//
//
//
//	
//
//}
//
